#ifndef QUEUE_h
#define QUEUE_h
#include "LinkedList.h"
#include <stdbool.h>

typedef struct Stack* Queue;

Stack       QueueCreate();
void        QueueDestroy(Queue);
void        QueuePush(Queue, Element);
Element     QueueEnqueue(Queue);
Element     QueueDequeue(Queue);
bool        QueueIsEmpty(Queue);

#endif

