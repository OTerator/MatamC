#include "BST.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

// Add whatever helper functions you need here

int main () {
    char* words[] = {"orange", "banana", "apple", "cherry", "date", "fig", "grape", "elderberry"};
    int n = sizeof(words) / sizeof(words[0]);

    // 1. Creat the BST
    // 2. Add words to the BST
    // 3. Print in-order traversal
    // 4. Print height and number of nodes
    // 5. Search for a word
    // 6. Clone the tree and print cloned tree
    // 7. Destroy both trees
    // 8. Manually reorder the array "words" so that the resulting BST is balanced and its height is minimized

    return 0;
}