#include "LinkedList.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
    LinkedList ll = LLCreate();
    for(int i=0; i<=10; i++)
        LLAdd(ll, 0, &i);

    while(LLSize(ll) > 0) {
        Element e = LLRemove(ll, 0);
        printf("%d\n", *e);
        free(e);
    }

    LLDestroy(ll);

	return 0;
}
